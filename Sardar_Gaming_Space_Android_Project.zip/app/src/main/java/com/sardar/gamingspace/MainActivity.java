package com.sardar.gamingspace;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int red = 0xFFFF3030, white = 0xFFFFFFFF, muted = 0xFFAAAAAA;
    LinearLayout root;
    TextView addText(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(0, 10, 0, 10); return t;
    }
    void card(String title, String detail, Runnable action) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(1);
        box.setPadding(22, 14, 22, 14); box.setBackgroundColor(0xFF202020);
        TextView a = addText(title, 18, red); TextView b = addText(detail, 13, muted);
        box.addView(a); box.addView(b);
        if (action != null) box.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 8, 0, 8);
        root.addView(box, p);
    }
    void open(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { Toast.makeText(this, "Setting is not available on this phone", Toast.LENGTH_SHORT).show(); }
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(20, 20, 20, 20);
        root.setBackgroundColor(0xFF090909);
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView brand = addText("SARDAR GAMING SPACE", 25, white); brand.setGravity(Gravity.CENTER);
        root.addView(brand);
        TextView sub = addText("RED • BLACK • GAMING DASHBOARD", 12, red); sub.setGravity(Gravity.CENTER);
        root.addView(sub);
        card("DEVICE STATUS", "RAM and battery details are available in Android settings.", () -> open(Settings.ACTION_SETTINGS));
        card("NETWORK SETTINGS", "Open Wi-Fi and mobile network controls.", () -> open(Settings.ACTION_WIRELESS_SETTINGS));
        card("DISPLAY SETTINGS", "Refresh rate and brightness options (if supported by your phone).", () -> open(Settings.ACTION_DISPLAY_SETTINGS));
        card("BATTERY SETTINGS", "Check battery usage and power options.", () -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        card("APP SETTINGS", "Manage installed apps and permissions.", () -> open(Settings.ACTION_APPLICATION_SETTINGS));
        card("MULTI-TOUCH TEST", "Touch the button with two or three fingers to check touch response.", null);
        Button test = new Button(this); test.setText("START TOUCH TEST"); test.setTextColor(white); test.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));
        TextView result = addText("Touch points: 0", 17, white); test.setOnTouchListener((v, e) -> {
            result.setText("Touch points: " + e.getPointerCount()); return true;
        });
        root.addView(test); root.addView(result);
        TextView note = addText("Note: This app opens phone settings. It does not overclock hardware, unlock FPS, or guarantee lower ping.", 12, muted);
        root.addView(note);
    }
}
